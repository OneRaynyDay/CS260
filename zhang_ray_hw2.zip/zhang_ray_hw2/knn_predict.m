function [new_accu, train_accu, predicted_labels_new, predicted_labels_train] ...
    = knn_predict(train_data, train_label, new_data, new_label, k)
[N,D] = size(train_data);
[M,D] = size(new_data);

predicted_labels_train = zeros(N);
predicted_labels_new = zeros(M);
correct_labels = 0;
mask_list = 1:N;

for i=1:N
    mask = mask_list;
    mask(i) = [];
    vote_labels = train_label(mask);
    [k_dist, k_idx] = sort(sum((train_data(mask,:) - train_data(i,:)).^2, 2).^(0.5));
    k_idx = k_idx(1:k);
    k_dist = k_dist(1:k);
    
    predicted_labels_train(i) = mode(vote_labels(k_idx));
    
    correct_labels = correct_labels + (predicted_labels_train(i) == train_label(i));
end

train_accu = correct_labels/N;

correct_labels = 0;

for i=1:M
    [k_dist, k_idx] = sort(sum((train_data - new_data(i,:)).^2, 2).^(0.5));
    k_idx = k_idx(1:k);
    k_dist = k_dist(1:k);
    
    votes_labels = train_label(k_idx);
    predicted_labels_new(i) = mode(votes_labels);
    
    correct_labels = correct_labels + (predicted_labels_new(i) == new_label(i));
end

new_accu = correct_labels/M;
    
end

