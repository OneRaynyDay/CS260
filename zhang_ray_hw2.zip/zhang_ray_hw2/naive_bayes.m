function [new_accu, train_accu] = naive_bayes(train_data, train_label, new_data, new_label)
% naive bayes classifier
% Input:
%  train_data: N*D matrix, each row as a sample and each column as a
%  feature
%  train_label: N*1 vector, each row as a label
%  new_data: M*D matrix, each row as a sample and each column as a
%  feature
%  new_label: M*1 vector, each row as a label
%
% Output:
%  new_accu: accuracy of classifying new_data
%  train_accu: accuracy of classifying train_data 
%
% CS260, Homework 2

% The parameter size is O(CD), where C is # of classes and D is # of
% dimensions.

C = max(train_label); % We assume classes start from 1
[N,~] = size(train_data);
[M,D] = size(new_data);
% go through and construct the table:
posterior_table = zeros(C,D);
prior_table = zeros(C,1);

for i=1:C
    prior_table(i) = sum(train_label==i)/N;
    posterior_table(i,:) = posterior_table(i,:) + sum(train_data(train_label == i,:),1);
    % hinge func as per specs, possibly to reduce overfitting
    posterior_table(i,:) = max(0.1, posterior_table(i,:)/sum(train_label==i)); 
end
%% For training data %%
% We know the parameters are:
% Prior P(Y=1): pi = Nc/N.
% Posterior P(X|Y=1): for feature, if present, multiply by the theta. If
% not, multiply by 1-theta.
train_predictions = zeros(N,1);
for i=1:N
    % Constructing posterior probability:
    max_class = 0;
    max_prob = 0;
    for j=1:C
        prob = prior_table(j) * prod(posterior_table(j,train_data(i,:) == 1)) * prod(1-posterior_table(j,train_data(i,:) == 0));
        if prob > max_prob
            max_prob = prob;
            max_class = j;
        end
    end
    train_predictions(i) = max_class;
end
train_accu = mean(train_predictions == train_label);

%% For new data %%
% We know the parameters are:
% Prior P(Y=1): pi = Nc/N.
% Posterior P(X|Y=1): for feature, if present, multiply by the theta. If
% not, multiply by 1-theta.
new_predictions = zeros(M,1);
for i=1:M
    % Constructing posterior probability:
    max_class = 0;
    max_prob = 0;
    for j=1:C
        prob = prior_table(j) * prod(posterior_table(j,new_data(i,:) == 1)) * prod(1-posterior_table(j,new_data(i,:) == 0));
        if prob > max_prob
            max_prob = prob;
            max_class = j;
        end
    end
    new_predictions(i) = max_class;
end
new_accu = mean(new_predictions == new_label);
