warning('off','all')
warning
% Data preparation
num_cols = 7;
min_k = 1;
max_k = 25;
jump = 2;

% The i-th row will be (k = i, new accuracy, train accuracy) %
indices = zeros((max_k-min_k)/2+1, 3);

[features, list_of_features, num_features_per_category] = ...
    process_features('car_train.data', num_cols);

[dat_train, lab_train] = convert_data(features, list_of_features, ...
                            num_features_per_category, 'car_train.data', num_cols);
                        
[dat_test, lab_test] = convert_data(features, list_of_features, ...
                            num_features_per_category, 'car_test.data', num_cols);
                        
[dat_valid, lab_valid] = convert_data(features, list_of_features, ...
                            num_features_per_category, 'car_valid.data', num_cols);
                        
                        
% Feeding data in
[test_size,~] = size(dat_test);
[valid_size,~] = size(dat_valid);

counter = 1;
for k=min_k:jump:max_k
    [new_accu, train_accu] = knn_classify(dat_train, lab_train, dat_valid, lab_valid, k);
    indices(counter,:) = [k new_accu train_accu];
    fprintf('The value of K: %d, new accuracy: %d, train accuracy: %d\n', k, new_accu, train_accu)

    counter = counter+1;
end

[max_acc, max_idx] = max(indices(:,2));
k = indices(max_idx,1)

% The best k is 11 %

[new_accu, train_accu] = knn_classify(dat_train, lab_train, dat_valid, lab_valid, k);

fprintf('The value of the test accuracy is : %d\n', new_accu)

% Using the knn on the boundary dataset: %
load('boundary.mat')
series = [1 5 15 20];
counter = 1;
indices = zeros(numel(series), 2);

% To visualize: %
% scatter(features(labels == 1, 1), features(labels == 1, 2), 'b')
% hold on
% scatter(features(labels == -1, 1), features(labels == -1, 2), 'r')
% hold off

points = zeros(10000, 2);
count = 1;
for i=linspace(0,1,100)
    for j=linspace(0,1,100)
        points(count,:) = [i j];
        count = count + 1;
    end
end

for k=series
    [~, ~, new_labels, ~] = knn_predict(features, labels, points, zeros(10000,1), k);
%     fig = scatter(points(new_labels == 1, 1), points(new_labels == 1, 2));
%     hold on
%     scatter(points(new_labels == -1, 1), points(new_labels == -1, 2))
%     hold off
%     waitfor(fig)
end

%% Running FITCTREE %%
leaf_sizes = 1:10;
split_criterion = {'gdi', 'deviance'};
best_new_accu = 0;
best_leaf_size = 0;
best_split = '';

for i=leaf_sizes
    for j=split_criterion
        t = fitctree(dat_train, lab_train, 'MinLeafSize', i, 'SplitCriterion', j{1}, 'Prune', 'off');
        train_accu = mean(predict(t, dat_train) == lab_train);
        new_accu = mean(predict(t, dat_valid) == lab_valid);
        test_accu = mean(predict(t, dat_test) == lab_test);
        fprintf('The value of leaf size: %d, using criterion: %s, validation accuracy: %d, train accuracy: %d, test accuracy: %d\n', i, j{1}, new_accu, train_accu, test_accu)
        if new_accu > best_new_accu
            best_leaf_size = i;
            best_split = j{1};
            best_new_accu = new_accu;
        end
    end
end

fprintf('The best new accuracy: %d, value of leaf size: %d, using criterion: %s \n', best_new_accu, best_leaf_size, best_split)

t = fitctree(dat_train, lab_train, 'MinLeafSize', best_leaf_size, 'SplitCriterion', best_split, 'Prune', 'off');

best_test_accu = mean(predict(t, dat_test) == lab_test);
        
fprintf('Using it to train on test set: %d \n', best_test_accu)
%% Running Naive Bayes %%

[valid_accu, train_accu] = naive_bayes(dat_train, lab_train, dat_valid, lab_valid);
[test_accu, train_accu] = naive_bayes(dat_train, lab_train, dat_test, lab_test);
fprintf('The value of test accuracy: %d, validation accuracy: %d, train accuracy: %d\n', test_accu, valid_accu, train_accu)

%% Running MNRfit(Logistic regression) %%

model = mnrfit(dat_train, lab_train);
[~,A] = max(mnrval(model, dat_train), [], 2);
train_accu = mean(A == lab_train);
[~,B] = max(mnrval(model, dat_valid), [], 2);
valid_accu = mean(B == lab_valid);
[~,C] = max(mnrval(model, dat_test), [], 2);
test_accu = mean(C == lab_test);

fprintf('The value of test accuracy: %d, validation accuracy: %d, train accuracy: %d\n', test_accu, valid_accu, train_accu)
