function [ new_data ] = convert_mnr( data, num_features_per_category)
[N, D] = size(data);
[K,~] = size(num_features_per_category);

new_data = zeros(N,K-1);

cur_row = 1;

for i = 1:(K-1) % Looping over columns %
    for j = 1:num_features_per_category(i) % Looping over features %
        new_data(:,i) = new_data(:,i) + (data(:,cur_row) == 1) * j;
        cur_row = cur_row + 1;
    end
end

end

