% Data preparation
num_cols = 7;
min_k = 1;
max_k = 25;
jump = 2;

% The i-th row will be (k = i, new accuracy, train accuracy) %
indices = zeros((max_k-min_k)/2+1, 3);

[features, list_of_features, num_features_per_category] = ...
    process_features('car_train.data', num_cols);

[dat_train, lab_train] = convert_data(features, list_of_features, ...
                            num_features_per_category, 'car_train.data', num_cols);
                        
[dat_test, lab_test] = convert_data(features, list_of_features, ...
                            num_features_per_category, 'car_test.data', num_cols);
                        
[dat_valid, lab_valid] = convert_data(features, list_of_features, ...
                            num_features_per_category, 'car_valid.data', num_cols);
                        
                        
% Feeding data in
[test_size,~] = size(dat_test);
[valid_size,~] = size(dat_valid);

counter = 1;
for k=min_k:jump:max_k
    [new_accu, train_accu] = knn_classify(dat_train, lab_train, dat_valid, lab_valid, k);
    indices(counter,:) = [k new_accu train_accu];
    fprintf('The value of K: %d, new accuracy: %d, train accuracy: %d\n', k, new_accu, train_accu)

    counter = counter+1;
end

[max_acc, max_idx] = max(indices(:,2));
k = indices(max_idx,1)

% The best k is 11 %

[new_accu, train_accu] = knn_classify(dat_train, lab_train, dat_valid, lab_valid, k);

fprintf('The value of the test accuracy is : %d\n', new_accu)

% Using the knn on the boundary dataset: %
load('boundary.mat')
series = [1 5 15 20];
counter = 1;
indices = zeros(numel(series), 2);

% To visualize: %
% scatter(features(labels == 1, 1), features(labels == 1, 2), 'b')
% hold on
% scatter(features(labels == -1, 1), features(labels == -1, 2), 'r')
% hold off

points = zeros(10000, 2);
count = 1;
for i=linspace(0,1,100)
    for j=linspace(0,1,100)
        points(count,:) = [i j];
        count = count + 1;
    end
end

for k=series
    [~, ~, new_labels, ~] = knn_predict(features, labels, points, zeros(10000,1), k);
    fig = scatter(points(new_labels == 1, 1), points(new_labels == 1, 2));
    hold on
    scatter(points(new_labels == -1, 1), points(new_labels == -1, 2))
    hold off
    waitfor(fig)
end


