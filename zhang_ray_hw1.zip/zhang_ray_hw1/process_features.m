%Processing data%
function [features, list_of_features, num_features_per_category] = ...
         process_features(file_name, num_cols)

out = textread(file_name, '%s', 'whitespace',',');
out = reshape(out, num_cols, [])';
[N,~] = size(out);

features = 0;
list_of_features = [];
num_features_per_category = zeros(num_cols,1);

for i=1:num_cols
    keys = unique(out(:,i));
    num_features_per_category(i) = numel(keys);
    list_of_features = cat(1, list_of_features, keys);
    if i ~= num_cols
        features = features + numel(unique(out(:,i)));
    end
end

end