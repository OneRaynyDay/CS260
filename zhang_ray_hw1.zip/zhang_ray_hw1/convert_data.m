function [dat, labels] = convert_data(features, list_of_features, ...
                            num_features_per_category, file_name, num_cols)
% generate numerical data %
out = textread(file_name, '%s', 'whitespace',',');
out = reshape(out, num_cols, [])';
[N,~] = size(out);

dat = zeros(N, features);
labels = zeros(N, 1);
count = 1;

for i = 1:num_cols-1 % Looping over columns %
    for j = 1:num_features_per_category(i) % Looping over features %
        for k = 1:N % Looping over samples %
            dat(k,count) = strcmp(list_of_features(count), out(k,i));
        end
        count = count + 1;
    end
end

for i = 1:num_features_per_category(end)
    for k = 1:N
        if strcmp(list_of_features(features+i), out(k, end))
            labels(k) = i;
        end
    end
end

