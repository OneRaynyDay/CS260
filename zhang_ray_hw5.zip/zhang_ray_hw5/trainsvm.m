function [w,b] = trainsvm(train_data, train_label, C)
% Train linear SVM (primal form)
% Input:
%  train_data: N*D matrix, each row as a sample and each column as a
%  feature
%  train_label: N*1 vector, each row as a label
%  C: tradeoff parameter (on slack variable side)
%
% Output:
%  w: feature vector (column vector)
%  b: bias term
%
[N,D] = size(train_data);

% Will be shaped in the format of w, b, xi
H = diag([ones(D,1); 0; zeros(N,1)]); % Used in w^Tw

f = [zeros(D,1); 0; ones(N,1) .* C]; % Used in C*sum(xi)

% First condition: yi(w^T*xi + b) + xi >= 1
A = -1.*[train_data .* train_label, train_label, diag(ones(N,1))];

b = -1.*ones(N,1);

lb = [-inf(D+1,1); zeros(N,1)];

% No outputs
options = optimset('Display', 'off');

[args,~,~,~,~] = quadprog(H,f,A,b,[],[],lb,[],[],options);
w = args(1:D);
b = args(D+1);