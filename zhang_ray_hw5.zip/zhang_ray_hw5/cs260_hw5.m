train = load('splice_train.mat');
test = load('splice_test.mat');

X_train = double(train.data);
y_train = train.label;
X_test = double(test.data);
y_test = test.label;

% Renormalization:
X_mean = mean(X_train, 1);
X_std = std(X_train, 1);

X_train = (X_train - X_mean) ./ X_std;
X_test = (X_test - X_mean) ./ X_std;

fprintf('The third feature has mean: %d and std: %d.\nThe tenth feature has mean %d and std: %d.\n', ...
    X_mean(3), X_std(3), X_mean(10), X_std(10));

%% Performing 5-fold Cross Validation %%
C = linspace(-6, 2, 9);

[N,D] = size(X_train);

X_valid = reshape(X_train, 5, [], D);
y_valid = reshape(y_train, 5, []);

for c=C
    total_time = 0;
    total_accuracy = 0;
    for i=1:5
        X_valid_train = reshape([X_valid(1:(i-1),:,:); X_valid((i+1):end,:,:)], N*(4/5), D);
        y_valid_train = reshape([y_valid(1:(i-1),:); y_valid((i+1):end,:)], N*(4/5), 1);
        begin = tic;
        [w,b] = trainsvm(X_valid_train, y_valid_train, 4^c);
        done = toc(begin);
        total_time = total_time + done;
        total_accuracy = total_accuracy + testsvm(reshape(X_valid(i,:,:), N/5, D), reshape(y_valid(i,:), [], 1), w, b);
    end

    fprintf('C = 4^%d\n', c);
    fprintf('average time : %f and average accuracy : %f\n', total_time / 5, total_accuracy / 5);
end

%% Testing C = 4^-4
fprintf('When C = 4^-3, average accuracy : 8.060000e-01, which is the highest point we have.\n');
[w,b] = trainsvm(X_train, y_train, 4^(2));
fprintf('Accuracy of test : %f\n', testsvm(X_test, y_test, w, b));

%% Using LIBSVM

%% Linear
libsvm_acc = zeros(length(C),1);
libsvm_time = zeros(length(C),1);
i = 1;
for c=C
    total_time = 0;
    total_accuracy = 0;
    str = sprintf('-c %f -t 0 -v 5', 4^c);
    begin = tic;
    libsvm_acc(i) = svmtrain(y_train, X_train, str);
    libsvm_time(i) = toc(begin);
    i = i+1;
end

for i=1:length(C)
    fprintf('C = 4^%d ',C(i));
    fprintf('average accuracy : %f and time : %f\n', libsvm_acc(i), libsvm_time(i)); 
end


%% Polynomial
C = linspace(-4,7,12);
deg = [1 2 3];

libsvm_acc = zeros(length(C),length(deg));
libsvm_time = zeros(length(C),length(deg));

i = 1;
for c=C
    j = 1;
    for d=deg
        str = sprintf('-c %f -t 1 -d %d -v 5', 4^c, d);
        begin = tic;
        libsvm_acc(i, j) = svmtrain(y_train, X_train, str);
        libsvm_time(i, j) = toc(begin);
        j = j+1;
    end 
    i = i+1;
end

for i=1:length(C)
    for j=1:length(deg)  
        fprintf('C = 4^%d, deg = %d, ',C(i), deg(j));
        fprintf('average accuracy : %f and time : %f\n', libsvm_acc(i, j), libsvm_time(i)); 
    end
end

%% Polynomial testing
model = svmtrain(y_train, X_train, '-c 0.25 -t 1 -d 1');
acc = mean(y_test == svmpredict(y_test, X_test, model));
fprintf('Highest accuracy is: %f on test data\n', acc);

%% RBF

C = linspace(-4,7,12);
gamma = linspace(-7,2,10);

libsvm_acc = zeros(length(C),length(gamma));
libsvm_time = zeros(length(C),length(gamma));

i = 1;
for c=C
    j = 1;
    for g=gamma
        str = sprintf('-c %f -t 2 -g %f -v 5', 4^c, 4^g);
        begin = tic;
        libsvm_acc(i, j) = svmtrain(y_train, X_train, str);
        libsvm_time(i, j) = toc(begin);
        j = j+1;
    end 
    i = i+1;
end

for i=1:length(C)
    for j=1:length(gamma)  
        fprintf('C = 4^%d, gamma = 4^%d, ',C(i), gamma(j));
        fprintf('average accuracy : %f and time : %f\n', libsvm_acc(i, j), libsvm_time(i)); 
    end
end

%% RBF testing
str = sprintf('-c 4 -t 2 -g %f', 4^-3);
model = svmtrain(y_train, X_train, str);
acc = mean(y_test == svmpredict(y_test, X_test, model));
fprintf('Highest accuracy is: %f on test data\n', acc);


