function [ acc ] = testNeuralNetwork(images, labels, T1, T2, X_mean, X_std)
% Test Neural Network (1 Hidden Layer)
% Input:
% images: data matrix
% labels: labels vector/matrix
% W1, W2: weights of the 1 hidden layer neural network
%
% Output:
% acc: accuracy of the neural network for the dataset

augment = @(X) [ones(size(X,1),1),X];
bounded_sigmoid = @(X) max(min(1./(1+exp(-X)), 1-1e-7), 1e-7);

X = images;
y = labels;

% Data preprocessing
X = permute(X, [3, 1, 2]);
X = double(reshape(X, [], 28*28));
X = augment(X);

X = (X - X_mean) ./ (X_std+1e-8);

A1 = X;
Z2 = A1*T1';
A2 = augment(tanh(Z2));
Z3 = A2*T2';
A3 = bounded_sigmoid(Z3);

[~,labels] = max(A3');
labels = (labels-1)';

acc = mean(labels == y);
end