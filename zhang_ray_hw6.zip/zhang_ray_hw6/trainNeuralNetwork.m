function [ X_mean, X_std, T1, T2 ] = trainNeuralNetwork( images, labels, plot_it )
% Train Neural Network (1 Hidden Layer)
% Input:
% images: data matrix
% labels: labels vector/matrix
%
% Output:
% W1, W2: weights of the 1 hidden layer neural network

% Functions
augment = @(X) [ones(size(X,1),1),X];
one_hot = @(Y) full(ind2vec(((Y-min(Y)+1)')))';
bounded_sigmoid = @(X) max(min(1./(1+exp(-X)), 1-1e-7), 1e-7);

X_tr = images;
y_tr = labels;

% Data preprocessing
X_tr = permute(X_tr, [3, 1, 2]);
X_tr = double(reshape(X_tr, [], 28*28));
[N,D] = size(X_tr);

ordering = randperm(N);
X_tr = X_tr(ordering,:);
y_tr = y_tr(ordering,:);

X_tr = augment(X_tr);
y_tr_one_hot = one_hot(y_tr);


% Normalizing
X_mean = mean(X_tr, 1);
X_std = std(X_tr, 1);

X_tr = (X_tr - X_mean) ./ (X_std+1e-8);

% Parameters
H = 200; C = max(y_tr+1); % Include 0
T1 = randn(H, D+1)/1e2;
T2 = randn(C, H+1)/1e2;
vT1 = zeros(size(T1)); % Momentum terms
vT2 = zeros(size(T2));


% Hyperparameters
update_rates = 100;
total_iters = 10000;
base_learning_rate = 7e-4;
decay_rate = 5e-5;
batch_size = 64;
mu = 0.9;

% learning parameters
learning_rate = base_learning_rate;
history = zeros(total_iters/update_rates,1);

% Training
i = 0;
for iter = 1:total_iters
    if (i+1)*batch_size > N
        i = 1;
    end
    X = X_tr(i*batch_size+1:(i+1)*batch_size,:);
    y = y_tr_one_hot(i*batch_size+1:(i+1)*batch_size,:);
    i = i+1;
    
    A1 = X;
    Z2 = A1*T1';
    A2 = augment(tanh(Z2));
    Z3 = A2*T2';
    A3 = bounded_sigmoid(Z3);
    cross_entropy = sum(sum(-(y.*log(A3) + (1-y).*log(1-A3))));
    

    dT2 = (A3-y)'*A2;
    dZ2 = (A3-y)*T2;
    dA2 = dZ2(:,2:end).*(1-A2(:,2:end).^2);
    dT1 = dA2'*A1;
    
    vT2 = mu * vT2 - learning_rate * dT2;
    vT1 = mu * vT1 - learning_rate * dT1;

    T2 = T2 + vT2;
    T1 = T1 + vT1;
    
    if mod(iter,update_rates) == 0
        learning_rate = base_learning_rate * exp(-decay_rate * iter);
        history(iter/update_rates) = cross_entropy;
        fprintf('CE at %d-th iteration: %f\n', iter, cross_entropy);
    end
end

if plot_it == true
    plot(1:length(history), history);
    xlabel('Iterations (x100)');
    ylabel('Cross entropy cost');
    title('Cross Entropy vs. Epochs');
end

end