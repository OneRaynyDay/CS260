train_small = load('train_small.mat');
train = load('train.mat');
test = load('test.mat');
%%
[X_mean, X_std, T1, T2] = trainNeuralNetwork( ...
    train.train.images, train.train.labels, true );
%%
train_acc = testNeuralNetwork( ...
    train.train.images, train.train.labels, T1, T2, X_mean, X_std);
%%
test_acc = testNeuralNetwork( ...
    test.test.images, test.test.labels, T1, T2, X_mean, X_std);
%%
fprintf('accuracy of training data on final classifier is : %d\n', train_acc);
fprintf('accuracy of testing data on final classifier is : %d\n', test_acc);