function data = load_dir(prefix, dir_list, dict)
D = dict.Count;
data = zeros(length(dir_list)-1, D);
count = 1;
for str=dir_list
    str = strcat(prefix, str{:});
    if exist(str) == 2
        data(count,:) = load_emailspam(str, dict);
        count = count + 1;
    end
end
end
