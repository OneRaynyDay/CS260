function [ cross_entropy_history, w_magnitude, w, b ] = logistic_regression( X,y,iterations,eta, lambda, order)
% We don't have a lambda supplied

[N,D] = size(X);

w = zeros(D,1);
b = 0.1;
sigma = @(x)min(1 - 1e-16, max(1e-16, 1./(1+exp(-x))));
logistic = @(X,w,b)-sum(y.*log(sigma(X*w+b)) + (1-y).*log(1-sigma(X*w+b))) + lambda * (w'*w);
cross_entropy_history = zeros(iterations,1);

if order == 2 % pre-processing w for newton's method
eta = 0.01;
pre_lambda = lambda;
lambda = 0.05;
for i=1:5
    grad_w = X'*(sigma(X*w+b)-y)/N + 2*lambda*w;
    grad_b = sum(sigma(X*w+b)-y)/N;
    w = w - eta*grad_w;
    b = b - eta*grad_b;
end
lambda = pre_lambda;
end

for i=1:iterations
    cross_entropy_history(i) = logistic(X,w,b);
    y_hat = sigma(X*w+b);
    if order == 1
        grad_w = X'*(y_hat-y)/N + 2*lambda*w;
        grad_b = sum(y_hat-y)/N;
        
        w = w - eta*grad_w;
        b = b - eta*grad_b;
    elseif order == 2
        grad_w = X'*(y_hat-y) + 2*lambda*w;
        hess_w = X'*diag(y_hat.*(1-y_hat))*X;
        l2_hess = eye(size(hess_w)).*lambda*2;
        hess_w = hess_w + l2_hess;

        grad_b = sum(y_hat-y);
        hess_b = y_hat'*(1-y_hat);
        
        w = w - pinv(hess_w) * grad_w;
        b = b - pinv(hess_b) * grad_b;
    end
end

w_magnitude = norm(w);
end

