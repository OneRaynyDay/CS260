function [ bag ] = load_emailspam( file_path , dict)

% Dict is passed as a containers.Map

DELIMS = {' ', '.', ',', '?', '\f','\n','\r','\t','\v'};
email = char(double(fileread(file_path)));
email = strsplit(email, DELIMS);

bag = zeros(dict.Count, 1); % bag of words representation

for word=email
    word = word{:};
    if dict.isKey(word)
        bag(dict(word)) = bag(dict(word)) + 1; % add 1 for every word
    end
end

end

