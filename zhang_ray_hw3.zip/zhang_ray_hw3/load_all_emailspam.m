function [ sp_tr_dat, ha_tr_dat, sp_te_dat, ha_te_dat ] = load_all_emailspam( ...
         spam_train_dir, ham_train_dir, spam_test_dir, ham_test_dir, dict)

spam_trains = strsplit(ls(spam_train_dir), '\n');
ham_trains = strsplit(ls(ham_train_dir), '\n');
spam_tests = strsplit(ls(spam_test_dir), '\n');
ham_tests = strsplit(ls(ham_test_dir), '\n');

sp_tr_dat = load_dir(spam_train_dir, spam_trains, dict);
ha_tr_dat = load_dir(ham_train_dir, ham_trains, dict);
sp_te_dat = load_dir(spam_test_dir, spam_tests, dict);
ha_te_dat = load_dir(ham_test_dir, ham_tests, dict);

end



