function [ dictionary, index_map] = load_dictionary( dictionary_path )

dict = table2array(readtable(dictionary_path, 'ReadVariableNames', false));
[N,~] = size(dict);

dict = lower(dict);

dictionary = containers.Map(dict, 1:N);
index_map = containers.Map(1:N, dict);
end

