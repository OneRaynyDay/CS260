[lab_train_iono, dat_train_iono] = load_ionosphere('ionosphere/ionosphere_train.dat');
[lab_test_iono, dat_test_iono] = load_ionosphere('ionosphere/ionosphere_test.dat');

[dict, idx_map] = load_dictionary('spam/dic.dat');
D = dict.Count;
%str = 'spam/train/spam/5138.2005-09-04.GP.spam.txt';

spam_train_dir = 'spam/train/spam/';
ham_train_dir = 'spam/train/ham/';
spam_test_dir = 'spam/test/spam/';
ham_test_dir = 'spam/test/ham/';

[sp_tr_dat, ha_tr_dat, sp_te_dat, ha_te_dat] = ...
load_all_emailspam(spam_train_dir, ham_train_dir, spam_test_dir, ham_test_dir, dict);

% initialization for spam emails
[N_sp,~] = size(sp_tr_dat);
[N_ha,~] = size(ha_tr_dat);
[N_sp_t,~] = size(sp_te_dat);
[N_ha_t,~] = size(ha_te_dat);

lab_train_email = [ones(N_sp,1); zeros(N_ha,1)];
lab_test_email = [ones(N_sp_t,1); zeros(N_ha_t,1)];
dat_train_email = [sp_tr_dat;ha_tr_dat];
dat_test_email = [sp_te_dat;ha_te_dat];

%% Answering #2 Q1 %%

[occurence, idx] = sort(sum(sp_tr_dat) + sum(ha_tr_dat), 'descend');

fprintf('{(%s: %d), (%s: %d), (%s: %d)}\n', idx_map(idx(1)), occurence(1), ...
    idx_map(idx(2)), occurence(2), idx_map(idx(3)), occurence(3))
                   
%% Answering #2 Q3 %%

iterations=50;

etas = [0.001 0.01 0.05 0.1 0.5];
lambdas = 0;

X = dat_train_email;
y = lab_train_email;

test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Email Logistic Regression Loss (Varying eta)', 'iterations', 'cross entropy', [],[],1)

X = dat_train_iono;
y = lab_train_iono;

test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Ionosphere Logistic Regression Loss (Varying eta)', 'iterations', 'cross entropy',[],[],1)
%% Answering #2 Q4 a) %%

lambdas = 0.1;

X = dat_train_email;
y = lab_train_email;

test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Email Logistic Regression Loss (Varying eta)', 'iterations', 'cross entropy',[],[],1)

X = dat_train_iono;
y = lab_train_iono;

test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Ionosphere Logistic Regression Loss (Varying eta)', 'iterations', 'cross entropy',[],[],1)

%% Answering #2 Q4 b) table %%
lambdas = linspace(0, 0.5, 11);

etas = 0.01;
X = dat_train_email;
y = lab_train_email;

test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Email Logistic Regression Loss (Varying lambda)', 'iterations', 'cross entropy', [],[],1)

X = dat_train_iono;
y = lab_train_iono;

test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Ionosphere Logistic Regression Loss (Varying lambda)', 'iterations', 'cross entropy', [],[],1)

%% Answering #2 Q4 c) plots %%

lambdas = linspace(0, 0.5, 11);
etas = [0.001 0.01 0.05 0.1 0.5];

X = dat_train_email;
y = lab_train_email;
X_test = dat_test_email;
y_test = lab_test_email;
test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Final Cross-Entropy for E-mail', 'lambdas', 'cross entropy', X_test, y_test,1)

X = dat_train_iono;
y = lab_train_iono;
X_test = dat_test_iono;
y_test = lab_test_iono;
test_hyperparameters(etas, lambdas, X, y, true, iterations, ...
    'Final Cross-Entropy for Ionosphere', 'lambdas', 'cross entropy', X_test, y_test,1)

%% Answering #3 Q6 b) plots %%

X = dat_train_email;
y = lab_train_email;
X_test = dat_test_email;
y_test = lab_test_email;
test_hyperparameters(1, lambdas, X, y, true, iterations, ...
    'Email Logistic Regression Loss (Varying lambda)', 'iterations', 'cross entropy', X_test, y_test,2)

X = dat_train_iono;
y = lab_train_iono;
X_test = dat_test_iono;
y_test = lab_test_iono;
test_hyperparameters(1, lambdas, X, y, true, iterations, ...
    'Ionosphere Logistic Regression Loss (Varying lambda)', 'iterations', 'cross entropy', X_test, y_test,2)

