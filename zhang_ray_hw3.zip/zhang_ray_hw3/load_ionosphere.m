function [ labels, data ] = load_ionosphere(file_path)
tbl = readtable(file_path);
[N,D] = size(tbl);
labels = table2array(tbl(:,D));

labels = ([labels{:}] == 'g')';

data = table2array(tbl(:,1:(D-1)));
end

